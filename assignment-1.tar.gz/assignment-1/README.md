# How to install
- git clone https://github.com/AndyCungkrinx/training-react.git
- npm install -f
- npm install --unsafe-perm node-sass

# How to run
- npm start

# Live Preview 
- https://assigment1.andycungkrinx.xyz

# Version
- Node v12.18.3
- Npm 6.14.6
- Npx 6.14.6
